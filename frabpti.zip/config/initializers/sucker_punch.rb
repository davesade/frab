require 'sucker_punch/async_syntax'
