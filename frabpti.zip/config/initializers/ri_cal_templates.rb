require 'ri_cal_templates'
