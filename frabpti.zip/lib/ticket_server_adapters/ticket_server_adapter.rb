class TicketServerAdapter

  def initialize(server)
    @server = server
    @logger = Rails.logger
  end

end
