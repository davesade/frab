module Cfp::WelcomeHelper
end
