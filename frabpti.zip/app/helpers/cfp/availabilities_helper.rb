module Cfp::AvailabilitiesHelper
end
