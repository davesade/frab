//= require jquery.flot.min
//= require jquery.flot.pie.min
//= require jquery.raty
//= require jquery.tools.min
//= require colorpicker
